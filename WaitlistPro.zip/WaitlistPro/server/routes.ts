import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertNewsletterSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Waitlist API endpoint
  app.post("/api/waitlist", async (req: Request, res: Response) => {
    try {
      const validatedData = insertWaitlistSchema.parse(req.body);
      
      // Check if email is already in waitlist
      const existingEntry = await storage.getWaitlistByEmail(validatedData.email);
      if (existingEntry) {
        return res.status(409).json({ 
          message: "This email is already on our waitlist." 
        });
      }
      
      // Create waitlist entry
      const waitlistEntry = await storage.createWaitlistEntry(validatedData);
      res.status(201).json({
        message: "Successfully joined the waitlist!",
        data: waitlistEntry
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "An error occurred while processing your request." });
    }
  });
  
  // Get all waitlist entries - could be used for admin purposes
  app.get("/api/waitlist", async (_req: Request, res: Response) => {
    try {
      const entries = await storage.getAllWaitlistEntries();
      res.status(200).json({
        count: entries.length,
        data: entries
      });
    } catch (error) {
      res.status(500).json({ message: "An error occurred while fetching waitlist entries." });
    }
  });
  
  // Newsletter subscription endpoint
  app.post("/api/newsletter", async (req: Request, res: Response) => {
    try {
      const validatedData = insertNewsletterSchema.parse(req.body);
      
      // Check if email is already subscribed to newsletter
      const existingSubscription = await storage.getNewsletterByEmail(validatedData.email);
      if (existingSubscription) {
        return res.status(409).json({ 
          message: "This email is already subscribed to our newsletter." 
        });
      }
      
      // Add to newsletter
      const newsletterEntry = await storage.addToNewsletter(validatedData);
      res.status(201).json({
        message: "Successfully subscribed to the newsletter!",
        data: newsletterEntry
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "An error occurred while processing your request." });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
