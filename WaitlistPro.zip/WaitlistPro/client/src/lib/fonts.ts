// Define font variables for use throughout the application
export const fonts = {
  playfair: '"Playfair Display", serif',
  montserrat: 'Montserrat, sans-serif',
  cormorant: '"Cormorant Garamond", serif'
};
