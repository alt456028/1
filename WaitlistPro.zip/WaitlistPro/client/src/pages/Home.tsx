import React from "react";
import HeroSection from "@/components/HeroSection";

export default function Home() {
  return (
    <div className="bg-black text-white font-montserrat min-h-screen">
      <HeroSection />
    </div>
  );
}
