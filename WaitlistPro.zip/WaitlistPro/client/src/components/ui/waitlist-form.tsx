import React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

// Form validation schema
const waitlistSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  size: z.string().optional(),
  notifications: z.boolean().default(true)
});

type WaitlistFormValues = z.infer<typeof waitlistSchema>;

export default function WaitlistForm() {
  const { toast } = useToast();

  // Initialize form
  const form = useForm<WaitlistFormValues>({
    resolver: zodResolver(waitlistSchema),
    defaultValues: {
      name: "",
      email: "",
      size: undefined,
      notifications: true
    }
  });

  // Submit waitlist mutation
  const { mutate, isPending, isSuccess } = useMutation({
    mutationFn: async (data: WaitlistFormValues) => {
      const response = await apiRequest("POST", "/api/waitlist", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Successfully joined the waitlist!",
        description: "We'll notify you when our collection launches.",
        variant: "default"
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Handle form submission
  function onSubmit(data: WaitlistFormValues) {
    mutate(data);
  }

  // Success state UI
  if (isSuccess) {
    return (
      <div className="p-4 bg-green-900 bg-opacity-20 border border-green-800 rounded-md">
        <p className="text-green-400 text-center font-montserrat">
          Thank you for joining our waitlist! We'll notify you when our collection launches.
        </p>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-nazr-light">Full Name</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    className="form-input w-full bg-nazr-black border border-nazr-dark text-nazr-light px-4 py-3 rounded-md focus:outline-none transition-all duration-300"
                    placeholder="Your name"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-nazr-light">Email Address</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="email"
                    className="form-input w-full bg-nazr-black border border-nazr-dark text-nazr-light px-4 py-3 rounded-md focus:outline-none transition-all duration-300"
                    placeholder="Your email"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="size"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-nazr-light">Preferred Size</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className="form-input w-full bg-nazr-black border border-nazr-dark text-nazr-light px-4 py-3 rounded-md focus:outline-none transition-all duration-300">
                    <SelectValue placeholder="Select your size" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent className="bg-nazr-black border border-nazr-dark text-nazr-light">
                  <SelectItem value="xs">XS</SelectItem>
                  <SelectItem value="s">S</SelectItem>
                  <SelectItem value="m">M</SelectItem>
                  <SelectItem value="l">L</SelectItem>
                  <SelectItem value="xl">XL</SelectItem>
                  <SelectItem value="xxl">XXL</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="notifications"
          render={({ field }) => (
            <FormItem className="flex items-start space-x-3 space-y-0">
              <FormControl>
                <Checkbox
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  className="bg-nazr-black border border-nazr-dark rounded focus:ring-nazr-red focus:ring-2"
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel className="text-nazr-gray font-montserrat">
                  I want to receive notifications about new collections and exclusive offers.
                </FormLabel>
              </div>
            </FormItem>
          )}
        />
        
        <div className="text-center">
          <motion.div
            whileHover={{ y: -2, boxShadow: "0 10px 15px -3px rgba(191, 0, 0, 0.2)" }}
          >
            <Button
              type="submit"
              disabled={isPending}
              className="nazr-button bg-nazr-red hover:bg-nazr-bright-red text-nazr-light px-8 py-3 rounded inline-flex items-center transition-all duration-300 font-montserrat uppercase tracking-wider"
            >
              {isPending ? "Submitting..." : "Join Waitlist"}
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </Button>
          </motion.div>
        </div>
      </form>
    </Form>
  );
}
