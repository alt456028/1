import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Form validation schema
const newsletterSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address." })
});

type NewsletterFormValues = z.infer<typeof newsletterSchema>;

export default function NewsletterForm() {
  const { toast } = useToast();
  
  // Initialize form
  const form = useForm<NewsletterFormValues>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: {
      email: ""
    }
  });
  
  // Submit newsletter mutation
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: NewsletterFormValues) => {
      const response = await apiRequest("POST", "/api/newsletter", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Thank you!",
        description: "You've successfully subscribed to our newsletter.",
        variant: "default"
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Handle form submission
  function onSubmit(data: NewsletterFormValues) {
    mutate(data);
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col md:flex-row gap-4 max-w-lg mx-auto">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem className="flex-grow">
              <FormControl>
                <Input
                  {...field}
                  type="email"
                  placeholder="Your email address"
                  className="form-input flex-grow bg-nazr-black border border-nazr-dark text-nazr-light px-4 py-3 rounded-md focus:outline-none transition-all duration-300"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <motion.div
          whileHover={{ y: -2, boxShadow: "0 10px 15px -3px rgba(191, 0, 0, 0.2)" }}
        >
          <Button
            type="submit"
            disabled={isPending}
            className="nazr-button bg-nazr-red hover:bg-nazr-bright-red text-nazr-light px-6 py-3 rounded transition-all duration-300 font-montserrat uppercase tracking-wider text-sm"
          >
            {isPending ? "Subscribing..." : "Subscribe"}
          </Button>
        </motion.div>
      </form>
    </Form>
  );
}
