import React from "react";

interface LogoProps {
  className?: string;
}

export default function Logo({ className = "h-12" }: LogoProps) {
  return (
    <div className={className}>
      <img 
        src="/images/logo-exact.png" 
        alt="NAZR Logo" 
        className="w-full h-full object-contain"
      />
    </div>
  );
}
