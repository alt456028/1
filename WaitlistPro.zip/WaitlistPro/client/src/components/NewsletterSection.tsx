import React from "react";
import SectionReveal from "./animations/SectionReveal";
import NewsletterForm from "./ui/newsletter-form";
import { FaInstagram, FaTwitter, FaFacebook, FaTiktok } from "react-icons/fa";
import { motion } from "framer-motion";

export default function NewsletterSection() {
  return (
    <SectionReveal>
      <section className="py-16 bg-nazr-dark relative overflow-hidden">
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="font-playfair text-2xl md:text-3xl font-bold text-nazr-light mb-4">
              Stay Connected
            </h3>
            <p className="font-cormorant text-xl text-nazr-gray mb-8">
              Subscribe to our newsletter for exclusive updates and behind-the-scenes content.
            </p>
            
            <NewsletterForm />
            
            <div className="mt-10">
              <div className="flex justify-center space-x-6">
                <SocialLink Icon={FaInstagram} href="#" />
                <SocialLink Icon={FaTwitter} href="#" />
                <SocialLink Icon={FaFacebook} href="#" />
                <SocialLink Icon={FaTiktok} href="#" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}

interface SocialLinkProps {
  Icon: React.ElementType;
  href: string;
}

function SocialLink({ Icon, href }: SocialLinkProps) {
  return (
    <motion.a
      href={href}
      className="text-nazr-light hover:text-nazr-red transition-colors duration-300"
      whileHover={{ y: -3 }}
    >
      <Icon className="text-2xl" />
    </motion.a>
  );
}
