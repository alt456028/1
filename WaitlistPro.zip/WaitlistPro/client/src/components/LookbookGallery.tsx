import React from "react";
import { motion } from "framer-motion";
import SectionReveal from "./animations/SectionReveal";

// Gallery images
const galleryImages = [
  {
    id: 1,
    src: "https://images.unsplash.com/photo-1550614000-4895a10e1bfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    alt: "Lookbook image 1",
    colSpan: "lg:col-span-2 lg:row-span-2"
  },
  {
    id: 2,
    src: "https://images.unsplash.com/photo-1626379801357-537599884323?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    alt: "Lookbook image 2",
    colSpan: ""
  },
  {
    id: 3,
    src: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    alt: "Lookbook image 3",
    colSpan: ""
  },
  {
    id: 4,
    src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    alt: "Lookbook image 4",
    colSpan: ""
  },
  {
    id: 5,
    src: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    alt: "Lookbook image 5",
    colSpan: ""
  }
];

export default function LookbookGallery() {
  return (
    <SectionReveal>
      <section className="py-20 bg-nazr-dark relative overflow-hidden">
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-5xl font-bold text-nazr-light mb-4">
              Lookbook
            </h2>
            <div className="w-24 h-1 bg-nazr-red mx-auto mb-6"></div>
            <p className="font-cormorant text-xl text-nazr-gray max-w-2xl mx-auto">
              A visual journey through our exclusive collection.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {galleryImages.map((image, index) => (
              <GalleryImage 
                key={image.id} 
                image={image} 
                index={index}
              />
            ))}
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}

interface GalleryImageProps {
  image: {
    id: number;
    src: string;
    alt: string;
    colSpan: string;
  };
  index: number;
}

function GalleryImage({ image, index }: GalleryImageProps) {
  return (
    <motion.div 
      className={`overflow-hidden group rounded-md ${image.colSpan}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      viewport={{ once: true, margin: "-100px" }}
    >
      <motion.img 
        src={image.src} 
        alt={image.alt} 
        className="w-full h-full object-cover"
        whileHover={{ scale: 1.05 }}
        transition={{ duration: 0.7, ease: [0.33, 1, 0.68, 1] }}
      />
    </motion.div>
  );
}
