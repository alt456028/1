import React, { useState, useEffect } from "react";
import Logo from "./Logo";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 left-0 w-full ${scrolled ? 'bg-nazr-black bg-opacity-95' : 'bg-transparent'} z-50 py-4 transition-all duration-300`}>
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex justify-between items-center">
          <div className="logo">
            <Link href="/">
              <Logo className="h-10 md:h-12 cursor-pointer" />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink href="#home" label="Home" onClick={closeMobileMenu} />
            <NavLink href="#collection" label="Collection" onClick={closeMobileMenu} />
            <NavLink href="#about" label="About" onClick={closeMobileMenu} />
            <motion.a 
              href="#waitlist" 
              className="nazr-button bg-nazr-red text-nazr-light px-6 py-2 rounded transition-all duration-300 font-montserrat uppercase tracking-wider text-sm"
              whileHover={{ y: -2, boxShadow: "0 10px 15px -3px rgba(191, 0, 0, 0.2)" }}
              onClick={closeMobileMenu}
            >
              Join Waitlist
            </motion.a>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            onClick={toggleMobileMenu} 
            className="md:hidden text-nazr-light focus:outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={mobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}></path>
            </svg>
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <motion.div 
          id="mobile-menu" 
          className={`md:hidden pt-4 pb-2 border-t border-nazr-dark mt-4 ${mobileMenuOpen ? 'block' : 'hidden'}`}
          initial={false}
          animate={mobileMenuOpen ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex flex-col space-y-4">
            <NavLink href="#home" label="Home" onClick={closeMobileMenu} />
            <NavLink href="#collection" label="Collection" onClick={closeMobileMenu} />
            <NavLink href="#about" label="About" onClick={closeMobileMenu} />
            <a 
              href="#waitlist" 
              className="bg-nazr-red text-nazr-light px-4 py-2 rounded text-center transition-all duration-300 font-montserrat uppercase tracking-wider text-sm"
              onClick={closeMobileMenu}
            >
              Join Waitlist
            </a>
          </div>
        </motion.div>
      </div>
    </header>
  );
}

interface NavLinkProps {
  href: string;
  label: string;
  onClick?: () => void;
}

function NavLink({ href, label, onClick }: NavLinkProps) {
  return (
    <a 
      href={href}
      className="nav-link relative text-nazr-light hover:text-nazr-red transition-colors duration-300 font-montserrat uppercase tracking-wider text-sm" 
      onClick={onClick}
    >
      {label}
    </a>
  );
}
