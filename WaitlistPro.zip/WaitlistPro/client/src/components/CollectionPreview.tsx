import React from "react";
import { motion } from "framer-motion";
import SectionReveal from "./animations/SectionReveal";

// Sample products data
const products = [
  {
    id: 1,
    name: "The NAZR Jacket",
    description: "Limited edition. Premium craftsmanship with handstitched details.",
    image: "https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    name: "Signature Hoodie",
    description: "Premium cotton blend with custom embroidery and distressed details.",
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    name: "Essential Tee",
    description: "Heavyweight cotton with minimalist design and custom logo treatment.",
    image: "https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }
];

export default function CollectionPreview() {
  return (
    <SectionReveal>
      <section id="collection" className="py-20 bg-nazr-dark relative overflow-hidden">
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-5xl font-bold text-nazr-light mb-4">
              Preview Collection
            </h2>
            <div className="w-24 h-1 bg-nazr-red mx-auto mb-6"></div>
            <p className="font-cormorant text-xl text-nazr-gray max-w-2xl mx-auto">
              A glimpse of our exclusive premium collection. Luxury redefined for the modern connoisseur.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <motion.a
              href="#waitlist"
              className="nazr-button bg-transparent border-2 border-nazr-red text-nazr-light hover:bg-nazr-red px-8 py-3 rounded inline-flex items-center transition-all duration-300 font-montserrat uppercase tracking-wider"
              whileHover={{ y: -2, boxShadow: "0 10px 15px -3px rgba(191, 0, 0, 0.2)" }}
            >
              Get Early Access
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </motion.a>
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}

interface ProductProps {
  product: {
    id: number;
    name: string;
    description: string;
    image: string;
  };
}

function ProductCard({ product }: ProductProps) {
  return (
    <motion.div 
      className="product-card group relative overflow-hidden rounded-md bg-nazr-black"
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <div className="overflow-hidden">
        <motion.img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-80 object-cover"
          whileHover={{ scale: 1.03 }}
          transition={{ duration: 0.7, ease: [0.33, 1, 0.68, 1] }}
        />
      </div>
      <div className="p-4">
        <h3 className="font-playfair text-xl text-nazr-light mb-2">{product.name}</h3>
        <p className="font-montserrat text-nazr-gray text-sm mb-3">{product.description}</p>
        <div className="flex justify-between items-center">
          <span className="font-montserrat text-nazr-red font-semibold">Coming Soon</span>
          <motion.button 
            className="text-nazr-light text-sm hover:text-nazr-red transition-colors duration-300"
            whileHover={{ x: 3 }}
          >
            Notify Me
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
