import React from "react";
import Logo from "./Logo";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-10 bg-nazr-black border-t border-nazr-dark relative">
      <div className="absolute inset-0 texture-overlay"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Logo className="h-10" />
          </div>
          
          <nav className="flex space-x-6 mb-6 md:mb-0">
            <a href="#home" className="text-nazr-gray hover:text-nazr-red transition-colors duration-300 font-montserrat text-sm uppercase">
              Home
            </a>
            <a href="#collection" className="text-nazr-gray hover:text-nazr-red transition-colors duration-300 font-montserrat text-sm uppercase">
              Collection
            </a>
            <a href="#about" className="text-nazr-gray hover:text-nazr-red transition-colors duration-300 font-montserrat text-sm uppercase">
              About
            </a>
            <a href="#waitlist" className="text-nazr-gray hover:text-nazr-red transition-colors duration-300 font-montserrat text-sm uppercase">
              Waitlist
            </a>
          </nav>
          
          <div className="text-nazr-gray text-sm font-montserrat">
            &copy; {currentYear} NAZR. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
