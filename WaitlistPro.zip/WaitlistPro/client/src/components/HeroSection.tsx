import React from "react";
import { motion } from "framer-motion";
import Logo from "./Logo";
import FadeIn from "./animations/FadeIn";
import { Instagram, Youtube, Twitter, Share2, MessageSquare } from "lucide-react";

export default function HeroSection() {
  const navigationButtons = [
    { label: "SHOP", href: "#shop", isPrimary: true },
    { label: "CATALOG", href: "#catalog" },
    { label: "CONTACT", href: "#contact" },
    { label: "LOOKBOOK", href: "#lookbook" },
    { label: "PRE-ORDER", href: "#pre-order" }
  ];

  const socialLinks = [
    { Icon: Instagram, href: "https://instagram.com" },
    { Icon: Youtube, href: "https://youtube.com" },
    { Icon: Share2, href: "https://tiktok.com" },
    { Icon: Twitter, href: "https://twitter.com" },
    { Icon: MessageSquare, href: "https://discord.com" }
  ];

  return (
    <section id="home" className="flex flex-col items-center justify-between min-h-screen bg-black py-10">
      <div className="flex-1"></div>
      
      <div className="flex flex-col items-center justify-center flex-1">
        <FadeIn delay={0}>
          <Logo className="h-32 mx-auto mb-6" />
        </FadeIn>
        
        <FadeIn delay={0.3}>
          <p className="text-nazr-gray text-sm mb-8 tracking-wider text-center" style={{ lineHeight: '1.7' }}>
            <span className="text-nazr-red">➖</span>Dark aesthetics, underground roots –<br />
            a new wave in Pakistan, <span className="text-nazr-red">Abyss Awakens.</span>
          </p>
        </FadeIn>
        
        <div className="flex flex-col gap-2 items-center w-full max-w-xs">
          {navigationButtons.map((button, index) => (
            <FadeIn key={button.label} delay={0.4 + index * 0.1}>
              <motion.a
                href={button.href}
                className={`block w-full text-center border ${button.isPrimary ? 'border-nazr-red bg-transparent' : 'bg-transparent border-white'} text-white py-2 text-sm font-medium tracking-widest transition-all duration-300 hover:bg-white hover:text-black`}
                style={{ 
                  width: '200px',
                  height: '40px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                whileHover={{ y: -2 }}
              >
                {button.label}
              </motion.a>
            </FadeIn>
          ))}
        </div>
      </div>
      
      <div className="mt-auto">
        <div className="flex gap-4 mb-2">
          {socialLinks.map((link, index) => (
            <motion.a
              key={index}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-nazr-gray hover:text-nazr-red transition-colors duration-300"
              whileHover={{ y: -2 }}
            >
              <link.Icon size={16} />
            </motion.a>
          ))}
        </div>
        <div className="text-nazr-gray text-xs">
          © 2025 NAZR Collective
        </div>
      </div>
    </section>
  );
}