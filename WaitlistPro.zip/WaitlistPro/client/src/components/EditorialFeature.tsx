import React from "react";
import { motion } from "framer-motion";
import SectionReveal from "./animations/SectionReveal";

export default function EditorialFeature() {
  return (
    <SectionReveal>
      <section className="py-20 relative overflow-hidden parallax" style={{
        backgroundImage: "url('https://images.unsplash.com/photo-1551803091-e20673f15770?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')"
      }}>
        <div className="absolute inset-0 bg-nazr-black opacity-70"></div>
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.h2 
              className="font-playfair text-3xl md:text-5xl font-bold text-nazr-light mb-8 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              Crafted with <span className="text-nazr-red">precision</span>, designed for <span className="text-nazr-red">distinction</span>
            </motion.h2>
            
            <motion.p 
              className="font-cormorant text-xl text-nazr-gray mb-10 leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              Each piece in our collection is a testament to exquisite craftsmanship and uncompromising quality. We've reimagined luxury with a modern edge, creating garments that stand as statements of individuality.
            </motion.p>
            
            <motion.a
              href="#about"
              className="nazr-button bg-transparent text-nazr-light hover:text-nazr-red border-b-2 border-nazr-red inline-flex items-center transition-all duration-300 font-montserrat uppercase tracking-wider pb-1"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              whileHover={{ x: 5 }}
            >
              Discover Our Story
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </motion.a>
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}
