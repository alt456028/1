import React from "react";
import { motion } from "framer-motion";
import SectionReveal from "./animations/SectionReveal";
import { FaInstagram, FaTwitter, FaFacebook } from "react-icons/fa";

export default function BrandStory() {
  return (
    <SectionReveal>
      <section id="about" className="py-20 bg-nazr-black relative overflow-hidden">
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-20">
            <div className="lg:w-1/2">
              <motion.div 
                className="relative"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1604872441399-ff7c19e65d4c?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80" 
                  alt="Brand story image" 
                  className="rounded-md w-full h-auto"
                />
                <motion.div
                  className="absolute -bottom-6 -right-6 w-32 h-32 border-2 border-nazr-red"
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  viewport={{ once: true, margin: "-100px" }}
                ></motion.div>
              </motion.div>
            </div>
            
            <div className="lg:w-1/2">
              <motion.h2 
                className="font-playfair text-3xl md:text-5xl font-bold text-nazr-light mb-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                Our Story
              </motion.h2>
              
              <motion.div 
                className="w-24 h-1 bg-nazr-red mb-8"
                initial={{ opacity: 0, width: 0 }}
                whileInView={{ opacity: 1, width: 96 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true, margin: "-100px" }}
              ></motion.div>
              
              <motion.p 
                className="font-cormorant text-xl text-nazr-gray mb-6 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                Born from a passion for reimagining luxury apparel, NAZR represents the intersection of heritage craftsmanship and contemporary design. Our founder's vision was to create pieces that transcend seasonal trends while making a bold statement.
              </motion.p>
              
              <motion.p 
                className="font-cormorant text-xl text-nazr-gray mb-10 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                Each limited collection is meticulously crafted using premium materials and techniques passed down through generations. We believe in creating garments that tell a story—your story.
              </motion.p>
              
              <motion.div 
                className="flex space-x-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                <SocialLink Icon={FaInstagram} href="#" />
                <SocialLink Icon={FaTwitter} href="#" />
                <SocialLink Icon={FaFacebook} href="#" />
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}

interface SocialLinkProps {
  Icon: React.ElementType;
  href: string;
}

function SocialLink({ Icon, href }: SocialLinkProps) {
  return (
    <motion.a
      href={href}
      className="text-nazr-light hover:text-nazr-red transition-colors duration-300"
      whileHover={{ y: -3 }}
    >
      <Icon className="text-2xl" />
    </motion.a>
  );
}
