import React from "react";
import SectionReveal from "./animations/SectionReveal";
import WaitlistForm from "./ui/waitlist-form";

export default function WaitlistSection() {
  return (
    <SectionReveal>
      <section id="waitlist" className="py-20 bg-nazr-black relative overflow-hidden">
        <div className="absolute inset-0 texture-overlay"></div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <div className="max-w-3xl mx-auto bg-nazr-dark p-8 md:p-12 rounded-md shadow-2xl relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-nazr-black via-nazr-red to-nazr-black"></div>
            
            <div className="text-center mb-10">
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-nazr-light mb-4">
                Join the Waitlist
              </h2>
              <p className="font-cormorant text-xl text-nazr-gray">
                Be the first to know when our exclusive collection launches and get early access.
              </p>
            </div>
            
            <WaitlistForm />
          </div>
        </div>
      </section>
    </SectionReveal>
  );
}
