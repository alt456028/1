import React from "react";
import Logo from "./Logo";
import { motion } from "framer-motion";

export default function LoadingScreen() {
  return (
    <div className="loading-screen fixed top-0 left-0 w-full h-full bg-nazr-black flex justify-center items-center z-50">
      <div className="loader flex flex-col items-center justify-center">
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          className="mb-4"
        >
          <Logo className="w-20 h-auto" />
        </motion.div>
        <motion.div
          className="w-12 h-12 border-t-2 border-r-2 border-nazr-red rounded-full"
          animate={{ rotate: 360 }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      </div>
    </div>
  );
}
